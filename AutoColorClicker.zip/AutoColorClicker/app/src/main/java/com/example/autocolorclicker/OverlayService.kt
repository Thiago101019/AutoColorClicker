package com.example.autocolorclicker

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.TextView
import kotlin.math.roundToInt

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val views = mutableMapOf<String, TextView>()
    private val names = listOf("RED", "GREEN", "NEXT", "REPLAY")
    private val colors = listOf(0x99FF3333.toInt(),0x9933DD66.toInt(),0x994488FF.toInt(),0x99FFAA33.toInt())
    override fun onCreate() { super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager; showAll() }
    private fun showAll() {
        val sp=getSharedPreferences("cfg",0)
        names.forEachIndexed { i,n ->
            val v=TextView(this); v.text=n; v.textSize=11f; v.setTextColor(Color.WHITE); v.setBackgroundColor(colors[i]); v.setPadding(10,6,10,6); v.alpha=.9f
            val lp=WindowManager.LayoutParams(110,60, if(android.os.Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            lp.gravity=Gravity.TOP or Gravity.START; lp.x=sp.getInt(n+"x",80); lp.y=sp.getInt(n+"y",180+i*90)
            var sx=0; var sy=0; var ox=0; var oy=0
            v.setOnTouchListener { _,e -> when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX.roundToInt();sy=e.rawY.roundToInt();ox=lp.x;oy=lp.y;true};MotionEvent.ACTION_MOVE->{lp.x=ox+(e.rawX-sx).roundToInt();lp.y=oy+(e.rawY-sy).roundToInt();wm.updateViewLayout(v,lp);true};MotionEvent.ACTION_UP->{sp.edit().putInt(n+"x",lp.x+55).putInt(n+"y",lp.y+30).apply();true};else->false} }
            wm.addView(v,lp); views[n]=v
        }
    }
    override fun onDestroy(){ views.values.forEach{wm.removeView(it)}; views.clear(); super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
}
