package com.example.autocolorclicker

import android.app.*
import android.content.*
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity:Activity(){
    private val REQ=41; private var pendingCalibrate=false; private lateinit var sp:android.content.SharedPreferences
    private val names=listOf("RED","GREEN","NEXT","REPLAY")
    override fun onCreate(b:Bundle?){super.onCreate(b);sp=getSharedPreferences("cfg",0); build()}
    private fun build(){
        val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(28,28,28,28)
        val title=TextView(this);title.text="Auto Color Clicker";title.textSize=26f;root.addView(title)
        val info=TextView(this);info.text="Coloque os 4 marcadores sobre os botões. Depois capture a cor no centro de cada botão.";root.addView(info)
        names.forEach{n->
            val row=LinearLayout(this);row.gravity=Gravity.CENTER_VERTICAL
            val t=TextView(this);t.text=n; t.textSize=16f; row.addView(t,LinearLayout.LayoutParams(0,70,1f))
            val c=Button(this);c.text="Capturar cor";c.setOnClickListener{toast("A captura de cor acontece enquanto a tela está sendo compartilhada. Coloque o marcador no botão e use este botão.")};row.addView(c)
            root.addView(row)
        }
        val overlay=Button(this);overlay.text="Mostrar / posicionar marcadores";overlay.setOnClickListener{if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))}else startService(Intent(this,OverlayService::class.java))};root.addView(overlay)
        val access=Button(this);access.text="Ativar permissão de cliques";access.setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))};root.addView(access)
        val calib=Button(this);calib.text="CALIBRAR CORES + INICIAR";calib.setOnClickListener{startCapture(true)};root.addView(calib)
        val start=Button(this);start.text="INICIAR (cores já salvas)";start.setOnClickListener{startCapture(false)};root.addView(start)
        val stop=Button(this);stop.text="PARAR";stop.setOnClickListener{stopService(Intent(this,CaptureService::class.java));stopService(Intent(this,OverlayService::class.java))};root.addView(stop)
        setContentView(root)
    }
    private fun startCapture(calibrate:Boolean){pendingCalibrate=calibrate; val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;startActivityForResult(m.createScreenCaptureIntent(),REQ)}
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==REQ&&c==RESULT_OK&&d!=null){startService(Intent(this,CaptureService::class.java).putExtra("code",c).putExtra("data",d).putExtra("calibrate",pendingCalibrate));toast(if(calibrate) "Calibrando cores e iniciando" else "Automação iniciada")}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
