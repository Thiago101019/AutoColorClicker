package com.example.autocolorclicker

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.*
import android.os.*
import kotlin.math.abs

class CaptureService: Service(){
    private var reader:ImageReader?=null; private var calibrate=false; private var sampled=false; private var vd:android.hardware.display.VirtualDisplay?=null; private var last=0L
    private val names=listOf("RED","GREEN","NEXT","REPLAY")
    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{
        val ch=NotificationChannel("capture","Auto Color Clicker",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(7,Notification.Builder(this,"capture").setContentTitle("Auto Color Clicker").setContentText("Automação ativa").setSmallIcon(com.example.autocolorclicker.R.drawable.ic_launcher).build())
        if(vd==null){ calibrate=i?.getBooleanExtra("calibrate",false)?:false; val code=i?.getIntExtra("code",0)?:0; val data=i?.getParcelableExtra<Intent>("data")?:return START_NOT_STICKY; startCapture(code,data) }
        return START_STICKY
    }
    private fun startCapture(code:Int,data:Intent){
        val dm=resources.displayMetrics; val w=dm.widthPixels; val h=dm.heightPixels
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        vd=(getSystemService(DISPLAY_SERVICE) as DisplayManager).createVirtualDisplay("ACC",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,null)
        reader!!.setOnImageAvailableListener({r-> val now=SystemClock.uptimeMillis(); if(now-last<180)return@setOnImageAvailableListener; last=now; val im=r.acquireLatestImage()?:return@setOnImageAvailableListener; try{if(calibrate&&!sampled){sample(im);sampled=true}else process(im)}finally{im.close()} },Handler(Looper.getMainLooper()))
    }

    private fun sample(im:Image){
        val plane=im.planes[0]; val buf=plane.buffer; val row=plane.rowStride; val pix=plane.pixelStride; val sp=getSharedPreferences("cfg",0)
        for(n in names){ val x=sp.getInt(n+"x",-1); val y=sp.getInt(n+"y",-1); if(x<0||y<0)continue
            var sr=0;var sg=0;var sb=0;var c=0; for(dy in -6..6 step 3)for(dx in -6..6 step 3){val xx=x+dx;val yy=y+dy;if(xx<0||yy<0)continue;val p=yy*row+xx*pix;if(p+2>=buf.capacity())continue;sr+=buf.get(p).toInt() and 255;sg+=buf.get(p+1).toInt() and 255;sb+=buf.get(p+2).toInt() and 255;c++}; if(c>0)sp.edit().putInt(n+"r",sr/c).putInt(n+"g",sg/c).putInt(n+"b",sb/c).apply() }
    }
    private fun process(im:Image){
        val plane=im.planes[0]; val buf=plane.buffer; val row=plane.rowStride; val pix=plane.pixelStride; val sp=getSharedPreferences("cfg",0); val svc=ClickAccessibilityService.instance?:return
        // Avoid rapid repeated clicks. Each marker stores screen coordinates and sampled RGB.
        for(n in names){ val x=sp.getInt(n+"x",-1); val y=sp.getInt(n+"y",-1); if(x<0||y<0)continue
            val rr=sp.getInt(n+"r",-1); val gg=sp.getInt(n+"g",-1); val bb=sp.getInt(n+"b",-1); if(rr<0)continue
            if(match(buf,row,pix,x,y,rr,gg,bb)){
                val k="last_$n"; val t=sp.getLong(k,0); if(SystemClock.uptimeMillis()-t>700){ svc.click(x.toFloat(),y.toFloat()); sp.edit().putLong(k,SystemClock.uptimeMillis()).apply() }
            }
        }
    }
    private fun match(b:java.nio.ByteBuffer,row:Int,pix:Int,x:Int,y:Int,tr:Int,tg:Int,tb:Int):Boolean{
        var count=0; var hit=0; val rad=14
        for(dy in -rad..rad step 4)for(dx in -rad..rad step 4){ val xx=x+dx;val yy=y+dy;if(xx<0||yy<0)continue; val p=yy*row+xx*pix;if(p+2>=b.capacity())continue; val r=b.get(p).toInt() and 255; val g=b.get(p+1).toInt() and 255; val bl=b.get(p+2).toInt() and 255; count++; if(abs(r-tr)<45&&abs(g-tg)<45&&abs(bl-tb)<45)hit++ }
        return count>0 && hit.toFloat()/count>.22f
    }
    override fun onDestroy(){reader?.close();vd?.release();super.onDestroy()}
    override fun onBind(i:Intent?):IBinder?=null
}
